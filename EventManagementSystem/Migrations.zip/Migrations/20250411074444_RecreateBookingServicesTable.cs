﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace EventManagementSystem.Migrations
{
    /// <inheritdoc />
    public partial class RecreateBookingServicesTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Venues",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Venues",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "Venues",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "UserName",
                table: "VenueReviews",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "UserImage",
                table: "VenueReviews",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Comment",
                table: "VenueReviews",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Venues_RegistrarId",
                table: "Venues",
                column: "RegistrarId");

            migrationBuilder.AddForeignKey(
                name: "FK_Venues_Registrars_RegistrarId",
                table: "Venues",
                column: "RegistrarId",
                principalTable: "Registrars",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Venues_Registrars_RegistrarId",
                table: "Venues");

            migrationBuilder.DropIndex(
                name: "IX_Venues_RegistrarId",
                table: "Venues");

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "Venues",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100);

            migrationBuilder.AlterColumn<string>(
                name: "UserName",
                table: "VenueReviews",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "UserImage",
                table: "VenueReviews",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Comment",
                table: "VenueReviews",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.InsertData(
                table: "Venues",
                columns: new[] { "Id", "AdditionalImages", "Address", "Amenities", "AvailableEventTypes", "Capacity", "CleaningFee", "ContactEmail", "ContactPhone", "CreatedAt", "CustomerName", "CustomerProfilePicture", "Date", "Description", "Email", "EndTime", "Features", "GuestCount", "HostBookingCount", "HostImage", "HostMemberSince", "HostName", "HostResponseRate", "HostResponseTime", "ImageUrl", "IsActive", "IsAvailable", "IsFeatured", "Location", "MaxCapacity", "Name", "PricePerHour", "Rating", "RegistrarId", "ReviewCount", "Size", "StartTime", "Status", "Type", "UpdatedAt", "VenueId", "VenueTypes" },
                values: new object[,]
                {
                    { 1, "", "123 Main St, City", "WiFi,Parking,Catering Kitchen,Sound System", "Wedding,Corporate,Gala", 500, 200m, null, null, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "John Doe", "/images/users/default.jpg", new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "A luxurious ballroom perfect for weddings and corporate events", "customer@example.com", new TimeSpan(0, 17, 0, 0, 0), "Stage,Dance Floor,Bar", 0, 150, "/images/hosts/john-smith.jpg", new DateTime(2023, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "John Smith", 98, 1, "/images/venues/grand-ballroom.jpg", true, true, true, "Downtown", 500, "Grand Ballroom", 500m, 4.8000001907348633, 1, 45, 5000, new TimeSpan(0, 9, 0, 0, 0), "Available", "Ballroom", new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "Indoor" },
                    { 2, "", "456 Park Ave, City", "Parking,Restrooms,Power Supply", "Wedding,Party,Photography", 200, 150m, null, null, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "John Doe", "/images/users/default.jpg", new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Beautiful outdoor venue with lush gardens", "customer@example.com", new TimeSpan(0, 17, 0, 0, 0), "Gazebo,Water Feature,Lighting", 0, 85, "/images/hosts/sarah-johnson.jpg", new DateTime(2023, 2, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Sarah Johnson", 95, 2, "/images/venues/garden-paradise.jpg", true, true, false, "Suburbs", 200, "Garden Paradise", 300m, 4.5999999046325684, 1, 28, 8000, new TimeSpan(0, 9, 0, 0, 0), "Available", "Garden", new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "Outdoor" }
                });
        }
    }
}
